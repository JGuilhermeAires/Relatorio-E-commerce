SELECT
        *
FROM
        DIM_Customer

SELECT TOP 5
        City,
        COUNT(*) AS Qtd_Clientes_cidade
FROM
        DIM_Customer
GROUP BY
        City
ORDER BY
        Qtd_Clientes_cidade DESC
-- CIDADES DO SUL DOMINAM OS CLIENTES, ESPECIFICAMENTE CIDADES DE SANTA CATARINA

SELECT TOP 5
        State,
        COUNT(*) AS Qtd_Clientes
FROM
        DIM_Customer
GROUP BY
        State
ORDER BY
        Qtd_Clientes DESC;
-- OS ESTADOS DO SUL LIDERAM O NUMERO DE CLIENTES, SANTA CATARINA NO TOPO

SELECT
        Region,
        COUNT(*) AS Qtd_Clientes
FROM
        DIM_Customer
GROUP BY
        Region
ORDER BY
        Qtd_Clientes DESC;
-- H� MAIS CLIENTES NO SUL, TODAVIA, A DIFEREN�A � POUCA ENTRE AS OUTRAS REGI�ES. SUDESTE TEM UM BOM N�MERO MAS � A REGI�O COM MENOS CLIENTES, CENTRO OESTE N�O H� CLIENTES

SELECT DISTINCT
        STATE
FROM
        DIM_Customer
        -- DF, GO, MT, MS S�O OS ESTADOS QUE N�O H� CLIENTES, OU SEJA, PRECISA INTENCIFICAR O MARKETING NA REGI�O CENTRO-OESTE. 